//1.Declarative/definition/genneral Function
function msg():void{
    console.log("Funcyion TypeScript")
}

msg()