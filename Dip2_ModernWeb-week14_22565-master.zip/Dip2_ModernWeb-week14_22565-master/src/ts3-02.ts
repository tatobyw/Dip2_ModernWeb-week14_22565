//2.Express function
const message = function sayHi(fname:string):void{
    console.log(`Hello ${fname}`)
}

message("Chananthon Thanomngoen")