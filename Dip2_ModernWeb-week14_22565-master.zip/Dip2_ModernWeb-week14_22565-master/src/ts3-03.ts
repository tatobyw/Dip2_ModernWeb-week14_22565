//3.Anonymous Function
const hello = function (fname:string):void{
    console.log(`Hello ${fname}`)
}

hello("Chananthon Thanomngoen")