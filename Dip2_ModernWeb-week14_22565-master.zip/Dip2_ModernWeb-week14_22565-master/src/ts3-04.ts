//4.Arrow Function
const takeAma = (fname:string):void => console.log(`Hello ${fname}`)

takeAma("AMA")